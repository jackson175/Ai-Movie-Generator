from diffusers import StableDiffusionPipeline

def generate_movie_poster(prompt):
    pipe = StableDiffusionPipeline.from_pretrained("CompVis/stable-diffusion-v1-4")
    pipe.to("cuda")  # Use GPU for faster processing

    image = pipe(prompt).images[0]
    file_path = f"static/{prompt.replace(' ', '_')}.png"
    image.save(file_path)

    return file_path