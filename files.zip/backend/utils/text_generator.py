import openai

openai.api_key = "your-openai-api-key"

def generate_movie_idea(prompt):
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=f"Generate a movie idea based on: {prompt}\nInclude a title and a short plot.",
        max_tokens=150
    )
    text = response["choices"][0]["text"].strip()
    lines = text.split("\n")
    title = lines[0].replace("Title:", "").strip()
    plot = " ".join(lines[1:]).replace("Plot:", "").strip()
    return {"title": title, "plot": plot}