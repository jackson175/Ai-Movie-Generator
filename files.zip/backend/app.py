from flask import Flask, request, jsonify
from utils.text_generator import generate_movie_idea
from utils.image_generator import generate_movie_poster

app = Flask(__name__)

@app.route('/generate', methods=['POST'])
def generate_movie():
    data = request.json
    genre = data.get("genre", "sci-fi")
    theme = data.get("theme", "futuristic adventure")

    # Generate text
    movie_idea = generate_movie_idea(f"{genre}, {theme}")

    # Generate image
    poster_path = generate_movie_poster(movie_idea["title"])

    return jsonify({
        "title": movie_idea["title"],
        "plot": movie_idea["plot"],
        "poster_url": poster_path
    })

if __name__ == "__main__":
    app.run(debug=True)